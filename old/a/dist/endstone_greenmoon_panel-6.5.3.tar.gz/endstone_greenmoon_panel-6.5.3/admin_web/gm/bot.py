"""``gm.bot`` —— 机器人 API（多卡片维度）。

面板支持多张「机器人卡片」独立启停，本模块按 ``adapter_id`` 定位到具体卡片；
不传 id 时默认取主官方机器人。

    from gm import bot

    # 机器人自身信息
    bot.info()                      # 主机器人
    bot.info("card-3")              # 指定卡片

    # 群聊信息
    bot.groups()                    # 主机器人的群列表
    bot.group("card-3", "A1B2C3")   # 某个群的详情

    # 所有卡片
    for card in bot.list():
        print(card["id"], card["name"], bot.status(card["id"]))

    # 发消息
    bot.send_text("card-3", "§a来自子插件的消息")
    bot.send_group("card-3", "群openid", "§e大家好")

权限：需在 manifest 声明 ``"bots"``。
"""

from __future__ import annotations

import threading
from typing import Any, Callable as _Callable, Dict, List, Optional

from ._context import current_owner, require_grant, require_plugin

# ⚠ 本模块定义了 ``def list(...)`` 作为对外 API（``bot.list()``），
# 这会把内置的 ``list`` **在模块全局里遮蔽掉**。于是下面这些写法会炸：
#
#     if isinstance(x, list):     # TypeError: isinstance() arg 2 must be a type
#     dict(got)                   # TypeError: 'function' object is not callable
#
# 而且报错信息是 ``isinstance() arg 2 must be a type`` 这种与业务毫无
# 关系的提示，极难定位。这里固定一份内置类型的引用，模块内一律用
# ``_list`` / ``_dict``，不再依赖内置名。
#
# 注意：不能写 ``_list = list`` —— 那时 ``list`` 还是内置的，没问题，
# 但为了防御「将来有人在前面又定义了什么」，直接用 ``builtins`` 取，
# 语义最明确、不依赖定义顺序。
import builtins as _bt

_list = _bt.list
_dict = _bt.dict

__all__ = [
    "list", "get", "status", "info", "gateway", "primary_id", "primary",
    "groups", "group", "send_text", "send_group", "send_group_async",
    "is_running", "is_connected",
    # 入站图片
    "on_image", "off_image", "image_handlers",
    "download_image", "download_image_async",
]

_SCOPE = "bots"


# ------------------------------------------------------------- 卡片与状态

def list(include_secrets: bool = False) -> List[Dict[str, Any]]:
    """返回全部机器人卡片。

    ``include_secrets=False``（默认）时密钥字段会被掩码，适合展示。
    """
    require_grant(_SCOPE)
    plugin = require_plugin()
    mgr = getattr(plugin, "conn_mgr", None)
    if mgr is None:
        return []
    try:
        return [_dict(x) for x in mgr.snapshot(mask=not include_secrets)
                if isinstance(x, _dict)]
    except Exception:
        return []


def get(adapter_id: str) -> Optional[Dict[str, Any]]:
    """取单张卡片的完整配置视图。"""
    require_grant(_SCOPE)
    plugin = require_plugin()
    mgr = getattr(plugin, "conn_mgr", None)
    if mgr is None:
        return None
    try:
        got = mgr.get_view(str(adapter_id))
    except Exception:
        return None
    return _dict(got) if isinstance(got, _dict) else None


def status(adapter_id: Optional[str] = None) -> Any:
    """运行状态。

    ``adapter_id`` 为空时返回**全部卡片**的状态列表；
    指定时返回该卡片的 dict，找不到返回 None。

    每项字段：``id`` / ``type`` / ``name`` / ``enabled`` / ``configured``
    / ``running`` / ``connected``
    """
    require_grant(_SCOPE)
    plugin = require_plugin()
    hub = getattr(plugin, "qq_hub", None)
    if hub is None:
        return [] if adapter_id is None else None
    try:
        items = [_dict(x) for x in hub.status() if isinstance(x, _dict)]
    except Exception:
        items = []
    if adapter_id is None:
        return items
    want = str(adapter_id)
    for it in items:
        if str(it.get("id")) == want:
            return it
    return None


def primary_id() -> Optional[str]:
    """主官方机器人的卡片 id；没有则返回 None。"""
    require_grant(_SCOPE)
    plugin = require_plugin()
    mgr = getattr(plugin, "conn_mgr", None)
    if mgr is None:
        return None
    try:
        card = mgr.primary_qqofficial()
    except Exception:
        return None
    if not card:
        return None
    got = card.get("id")
    return str(got) if got else None


def primary() -> Optional[Dict[str, Any]]:
    """主官方机器人的卡片信息。"""
    gid = primary_id()
    return get(gid) if gid else None


def _resolve_id(adapter_id: Optional[str]) -> Optional[str]:
    """把可选的 adapter_id 解析成具体 id（空则用主机器人）。"""
    if adapter_id:
        return str(adapter_id)
    return primary_id()


def info(adapter_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """机器人自身信息。

    返回 ``{id, name, type, enabled, configured, running, connected,
    app_id, groups_count, is_primary}``；找不到卡片返回 None。
    """
    require_grant(_SCOPE)
    gid = _resolve_id(adapter_id)
    if not gid:
        return None

    card = get(gid) or {}
    st = status(gid) or {}
    plugin = require_plugin()

    app_id = ""
    groups_count = 0
    try:
        mgr = getattr(plugin, "conn_mgr", None)
        if mgr is not None:
            flat = mgr.to_flat_config(card) if card else {}
            app_id = str(flat.get("app_id", "") or "")
    except Exception:
        pass
    groups_count = len(groups(gid))

    return {
        "id": gid,
        "name": str(st.get("name") or card.get("name") or ""),
        "type": str(st.get("type") or card.get("type") or ""),
        "enabled": bool(st.get("enabled", card.get("enabled", False))),
        "configured": bool(st.get("configured", False)),
        "running": bool(st.get("running", False)),
        "connected": bool(st.get("connected", False)),
        "app_id": app_id,
        "groups_count": groups_count,
        "is_primary": gid == (primary_id() or ""),
    }


def gateway(adapter_id: Optional[str] = None) -> Optional[Any]:
    """返回**原生网关对象**（透传）。

    qqofficial 卡片是 ``QQBotGateway``，websocket 卡片是 ``OneBotAdapter``。
    用于访问本模块未封装的底层能力；自行调用时请留意线程安全。
    """
    require_grant(_SCOPE)
    plugin = require_plugin()
    hub = getattr(plugin, "qq_hub", None)
    if hub is None:
        return None
    try:
        if adapter_id:
            return hub.gateway_by_id(str(adapter_id))
        return hub.primary_gateway()
    except Exception:
        return None


def is_running(adapter_id: Optional[str] = None) -> bool:
    """机器人是否已启动（网关进程/线程在跑）。"""
    st = status(_resolve_id(adapter_id))
    return bool(st and st.get("running"))


def is_connected(adapter_id: Optional[str] = None) -> bool:
    """机器人是否已连上平台（WebSocket 已建立）。"""
    st = status(_resolve_id(adapter_id))
    return bool(st and st.get("connected"))


# ------------------------------------------------------------------- 群聊

def groups(adapter_id: Optional[str] = None) -> List[Dict[str, Any]]:
    """返回某个机器人已绑定的群列表。

    每项 ``{openid, name, is_primary}``。数据来自卡片配置，纯读。
    """
    require_grant(_SCOPE)
    plugin = require_plugin()
    mgr = getattr(plugin, "conn_mgr", None)
    if mgr is None:
        return []

    if adapter_id:
        card = get(str(adapter_id))
    else:
        try:
            card = mgr.primary_qqofficial()
        except Exception:
            card = None
    if not card:
        return []

    try:
        flat = mgr.to_flat_config(card)
    except Exception:
        return []

    primary = str(flat.get("group_openid", "") or "").strip()
    items = flat.get("groups") or []
    if not isinstance(items, _list):
        items = []

    out: List[Dict[str, Any]] = []
    seen = set()
    if primary:
        out.append({"openid": primary, "name": primary, "is_primary": True})
        seen.add(primary)
    for g in items:
        if not isinstance(g, _dict):
            continue
        oid = str(g.get("openid", "") or "").strip()
        if not oid or oid in seen:
            continue
        seen.add(oid)
        out.append({
            "openid": oid,
            "name": str(g.get("name", "") or "").strip() or oid,
            "is_primary": False,
        })
    return out


def group(adapter_id: str, openid: str) -> Optional[Dict[str, Any]]:
    """返回某个群的信息。

    字段 ``{openid, name, is_primary, adapter_id, adapter_name, bound}``。
    """
    require_grant(_SCOPE)
    want = str(openid or "").strip()
    if not want:
        return None
    for g in groups(adapter_id):
        if str(g.get("openid")) == want:
            st = status(adapter_id) or {}
            return {
                "openid": want,
                "name": g.get("name") or want,
                "is_primary": bool(g.get("is_primary")),
                "adapter_id": str(adapter_id),
                "adapter_name": str(st.get("name") or ""),
                "bound": True,
            }
    return None


# ------------------------------------------------------------------- 发送

def send_text(adapter_id: Optional[str], text: str) -> bool:
    """向机器人的主群发送文本（异步入队，立即返回）。

    走网关内置发送队列，不会阻塞调用线程，也不会抛网络异常。
    """
    require_grant(_SCOPE)
    gw = gateway(adapter_id)
    if gw is None:
        return False
    body = str(text or "")
    if not body.strip():
        return False
    try:
        sender = getattr(gw, "send_qq_text", None)
        if callable(sender):
            sender(body)
            return True
    except Exception:
        pass
    return False


def send_group(adapter_id: Optional[str], group_id: str, text: str) -> bool:
    """向指定群发送文本。

    ⚠ 对 qqofficial 卡片是**同步网络调用**，可能阻塞数百毫秒到数秒。
    在服务器主线程或高频路径里调用会卡顿，建议改用 ``send_group_async()``。
    OneBot（websocket）卡片是异步入队，无此问题。
    """
    require_grant(_SCOPE)
    gw = gateway(adapter_id)
    if gw is None:
        return False
    body = str(text or "")
    target = str(group_id or "").strip()
    if not body.strip() or not target:
        return False

    # OneBot：直接入队，线程安全
    if getattr(gw, "adapter_type", None) == "websocket":
        try:
            gw.send_group_msg(int(target), body)
            return True
        except (TypeError, ValueError):
            # 群号不是数字时退回字符串，交给底层处理
            try:
                gw.send_group_msg(target, body)
                return True
            except Exception:
                return False
        except Exception:
            return False

    # qqofficial：同步 HTTP
    try:
        api = getattr(gw, "_api", None)
        if api is None:
            return False
        api.send_message_to(target, {"type": "text", "content": body}, "")
        return True
    except Exception:
        return False


def send_group_async(adapter_id: Optional[str], group_id: str, text: str) -> bool:
    """``send_group`` 的异步版本：丢到后台线程执行，立即返回。

    qqofficial 卡片的同步网络调用不会卡住调用方。
    """
    require_grant(_SCOPE)

    def _work() -> None:
        try:
            send_group(adapter_id, group_id, text)
        except Exception:
            pass

    threading.Thread(target=_work, name="gm-bot-send", daemon=True).start()
    return True


# --------------------------------------------------------------- 入站图片

def on_image(handler: Optional[_Callable] = None) -> Any:
    """注册「QQ 群里发来图片」的处理函数。

    两种写法都支持::

        @bot.on_image                    # 装饰器
        def _got(ev):
            print(ev.sender_name, ev.images)

        bot.on_image(_got)               # 普通调用

    ``ev`` 是 ``QQImageEvent``，字段见主插件 ``admin_web.qqbot.QQImageEvent``：

        ev.adapter_id    收到消息的机器人卡片 id
        ev.adapter_name  卡片显示名
        ev.group_id      群 openid
        ev.sender_id     发送者 member_openid（用来查账号绑定）
        ev.sender_name   发送者群昵称
        ev.images        图片列表 [{url, content_type, filename, size, width, height}]
        ev.text          同一消息里的文字（纯图消息为空串）
        ev.message_id    消息 id

    ⚠ ``ev.images[i]["url"]`` 是**带签名、会过期**的下载地址，
    拿到后应尽快下载，不要存起来慢慢用。

    只有**已绑定服务器**的群才会触发（未绑定的群不会派发），
    这样陌生人拉个群发图不会白白消耗服务器资源。

    权限：需在 manifest 声明 ``"bots"``。
    """
    require_grant(_SCOPE)

    if handler is None:
        def _decorator(fn: _Callable) -> _Callable:
            on_image(fn)
            return fn
        return _decorator

    plugin = require_plugin()
    lst = getattr(plugin, "_gm_image_hooks", None)
    if lst is None:
        lst = []
        try:
            plugin._gm_image_hooks = lst
        except Exception:
            return handler
    if handler not in lst:
        lst.append(handler)

    # 记录归属，便于子插件停用时清理（与 gm.event 同一套机制）
    owner = current_owner()
    if owner:
        try:
            handles = getattr(plugin, "_gm_image_owner", None)
            if handles is None:
                handles = {}
                plugin._gm_image_owner = handles
            handles.setdefault(owner, []).append(handler)
        except Exception:
            pass
    return handler


def off_image(handler: _Callable) -> bool:
    """取消注册图片处理函数。返回是否确实移除了一项。"""
    require_grant(_SCOPE)
    plugin = require_plugin()
    lst = getattr(plugin, "_gm_image_hooks", None)
    removed = False
    if lst and handler in lst:
        try:
            lst.remove(handler)
            removed = True
        except ValueError:
            pass

    owner = current_owner()
    if owner:
        try:
            handles = getattr(plugin, "_gm_image_owner", None) or {}
            items = handles.get(owner) or []
            handles[owner] = [x for x in items if x is not handler]
        except Exception:
            pass
    return removed


def image_handlers() -> List[Any]:
    """返回当前已注册的图片处理函数列表。"""
    require_grant(_SCOPE)
    plugin = require_plugin()
    lst = getattr(plugin, "_gm_image_hooks", None)
    return _list(lst) if isinstance(lst, _list) else []


def _drop_owner(plugin: Any, owner: str) -> int:
    """按 uuid 摘除该子插件注册的图片钩子（供 ModLoader 停用时调用）。"""
    handles = getattr(plugin, "_gm_image_owner", None)
    if not isinstance(handles, _dict):
        return 0
    items = handles.pop(owner, None)
    if not items:
        return 0
    lst = getattr(plugin, "_gm_image_hooks", None)
    count = 0
    if isinstance(lst, _list):
        for fn in items:
            try:
                lst.remove(fn)
                count += 1
            except ValueError:
                pass
    return count


def download_image(ev: Any, index: int = 0, timeout: float = 20.0) -> Optional[bytes]:
    """下载 ``QQImageEvent`` 里的第 ``index`` 张图片，返回原始字节。

    **为什么不让你自己 requests.get(url)**

    QQ 的图片下载地址需要带 ``QQBot <access_token>`` 认证头，而这个
    token 属于「收到该消息的那张机器人卡片」。子插件手上没有 token，
    自己发请求会拿到 401/403。本函数会自动用 ``ev.adapter_id`` 对应的
    卡片去取 token 并附上，你只管拿结果。

    返回 ``None`` 表示失败（无图片、卡片已停用、网络错误等），
    具体原因记在服务端日志里。

    用法::

        @bot.on_image
        def _got(ev):
            data = bot.download_image(ev)
            if not data:
                return
            ...  # data 是图片原始字节（png/jpg）

    权限：需在 manifest 声明 ``"bots"``。
    """
    require_grant(_SCOPE)

    imgs = getattr(ev, "images", None)
    if not isinstance(imgs, _list) or not (0 <= index < len(imgs)):
        return None
    item = imgs[index]
    if not isinstance(item, _dict):
        return None
    url = str(item.get("url") or "").strip()
    if not url:
        return None

    plugin = require_plugin()
    gw = gateway(getattr(ev, "adapter_id", None) or None)

    # 取该卡片的 access_token（用于拼认证头）。
    # 拿不到 token 也继续试 —— 有些代理网关的下载地址不需要认证。
    token = ""
    if gw is not None:
        try:
            api = getattr(gw, "_api", None)
            if api is not None:
                token = str(api.get_access_token() or "")
        except Exception:
            token = ""

    try:
        import urllib.request as _u
        req = _u.Request(url, method="GET")
        req.add_header("User-Agent", "GreenMoon/1.0")
        if token:
            req.add_header("Authorization", f"QQBot {token}")
        with _u.urlopen(req, timeout=timeout) as resp:
            return resp.read()
    except Exception as e:
        try:
            plugin.logger.warning(f"[gm.bot] 下载图片失败: {e}")
        except Exception:
            pass
        return None


def download_image_async(ev: Any, callback: _Callable,
                         index: int = 0, timeout: float = 20.0) -> bool:
    """异步下载图片，完成后在**后台线程**里调 ``callback(data_or_None)``。

    ⚠ 图片下载是网络 IO，可能耗时数秒。**不要在主线程直接调
    ``download_image``**（会卡服）；在图片钩子里请用本函数。

    注意 ``callback`` 运行在后台线程，若要改服务器状态，请回到主线程
    （``gm.server.run(...)``）。

    权限：需在 manifest 声明 ``"bots"``。
    """
    require_grant(_SCOPE)

    def _work() -> None:
        data = None
        try:
            data = download_image(ev, index=index, timeout=timeout)
        finally:
            try:
                callback(data)
            except Exception:
                pass

    threading.Thread(target=_work, name="gm-bot-img", daemon=True).start()
    return True
